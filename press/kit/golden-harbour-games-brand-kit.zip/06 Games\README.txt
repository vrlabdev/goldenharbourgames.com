Cover art for each game, 630 x 500, as on itch.io and goldenharbourgames.com.
Play pages:  https://goldenharbourgames.com/play/<game>/   (Russian: /ru/play/<game>/)
itch pages:  https://goldenharbourgames.itch.io/<game>
Games: peregon, punch-league, aerofire-command, vladivostok-fortress
