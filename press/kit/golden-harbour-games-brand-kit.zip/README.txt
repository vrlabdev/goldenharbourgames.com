GOLDEN HARBOUR GAMES - BRAND KIT (v1.0, September 2026)

Quick picks
  Profile picture anywhere ........ 03 Social/avatar-1000.png
  X header ......................... 03 Social/x-header-1500x500.png
  YouTube / Bluesky / VK / LinkedIn / Facebook banners ... 03 Social/
  Logo on a white document ........ 01 Logo/png/ghg-horizontal-on-light-1200w.png
  Logo on a dark slide or video ... 01 Logo/png/ghg-horizontal-on-dark-1200w.png
  Game splash screen .............. 01 Logo/png/ghg-stacked-on-dark-1200w.png
  Favicon / app icon .............. 02 Icons & favicons/
  Anything printed or scaled up ... 01 Logo/svg/  (vector, any size)
  Colours with hex/RGB/CMYK ....... 04 Colours/colours.txt
  Fonts ........................... 05 Fonts/  (free, install them)
  Email signature ................. 07 Email signature/signature.html
  The rules ....................... Brand guide.pdf

Names
  mark ......... the symbol alone (two suns, two bridges)
  mark-small ... the symbol without bridges, for 64 px and smaller
  horizontal ... symbol + GOLDEN HARBOUR / GAMES side by side
  stacked ...... symbol above the name
  wordmark ..... the name alone
  on-dark / on-light / two-tone-light / navy / white = which background it is for

PNG files have transparent backgrounds (except icons and social images) and come in several sizes;
the number is the size in pixels (-1200w = 1200 wide).

Made from the Identity board of the "Golden Harbour Games - Identity & Website" design canvas.
_source/ rebuilds everything: node build_kit.mjs, node render.mjs, node finish.mjs,
then print _source/render/guide.html to PDF with Edge:
  msedge --headless=new --no-pdf-header-footer --print-to-pdf="Brand guide.pdf" <file URL of guide.html>
(Edge refuses to print over DevTools, so render.mjs pdf-only does not work here.) Needs Node and Microsoft Edge.
