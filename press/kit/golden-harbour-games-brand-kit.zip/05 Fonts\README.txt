The three typefaces. All free (SIL Open Font License, the OFL-*.txt files):
use them anywhere, commercially too, and install them on any computer.

  Unbounded Bold / ExtraBold   headlines, game titles, the wordmark        fonts.google.com/specimen/Unbounded
  Golos Text Regular - SemiBold  body text, buttons, UI                     fonts.google.com/specimen/Golos+Text
  JetBrains Mono Regular/Medium  labels: coordinates, "01 / GAMES", genres  fonts.google.com/specimen/JetBrains+Mono
                                 always UPPERCASE and spaced out

All three cover Latin and Cyrillic, so English and Russian look the same.
To install on Windows: select the .ttf files, right-click, Install.
